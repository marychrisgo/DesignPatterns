package lab4.homework;

public interface Component {
    void iterate(Visitor visitor);
}
