package lab4.homework;

public interface Visitor {
    String getValue(Component component);
    void printResult();
}
