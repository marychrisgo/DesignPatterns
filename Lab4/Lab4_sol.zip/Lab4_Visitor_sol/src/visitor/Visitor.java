package visitor;

public interface Visitor {
    public void doRed(Red r);
    public void doBlue(Blue r);
}
