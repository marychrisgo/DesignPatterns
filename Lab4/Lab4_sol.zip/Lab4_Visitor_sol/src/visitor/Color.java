package visitor;

public abstract class Color {
    public abstract void accept(Visitor v);
}
