package lab3.homework;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

public class Main {

    public static void main(String[] args) {
        ArrayList<Household> houses = new ArrayList<>();
        Random r = new Random();
        Person.ageGroups = new ArrayList<>(Arrays.asList(4, 14, 29, 59, 69, 79, 101));
        ProbabilityFactory probabilityFactory = new ProbabilityFactory();
        //Create 100 households, with 5 people each
        for (int i = 0; i < 100; i++) {
            ArrayList<Person> people = new ArrayList<Person>();
            for (int j = 0; j < 5; j++) {
                //Extrinsic properties
                Person.Sex sex = null;
                if (r.nextBoolean()) {
                    sex = Person.Sex.Female;
                } else {
                    sex = Person.Sex.Male;
                }
                Integer age = r.nextInt(100);
                int index = i * 5 + j;

                //Intrinsic properties
                ArrayList<Double> probsSuddenDeath = probabilityFactory.getSuddenDeathProbabilities(sex);
                ArrayList<Double> probsHospital = probabilityFactory.getHospitalProbabilities(sex);
                ArrayList<Double> probsHospitalDeath = probabilityFactory.getHospitalDeathProbabilities(sex);

                Person person = new Person(probsHospital, probsHospitalDeath, probsSuddenDeath, age, sex, index);
                people.add(person);
            }
            houses.add(new Household(people, i));
        }

        //Iterate for 100 days
        for (int i = 0; i < 10000; i++) {
            for (Household h : houses) {
                h.newDay();
            }
        }
    }
}
