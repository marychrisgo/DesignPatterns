package lab3.homework;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

public class ProbabilityFactory {
    HashMap<Person.Sex, ArrayList<Double>> suddenDeathProbabilitiesMap = new HashMap<Person.Sex, ArrayList<Double>>();
    HashMap<Person.Sex, ArrayList<Double>> hospitalProbabilitiesMap = new HashMap<Person.Sex, ArrayList<Double>>();
    HashMap<Person.Sex, ArrayList<Double>> hospitalDeathProbabilitiesMap = new HashMap<Person.Sex, ArrayList<Double>>();

    public ArrayList<Double> getSuddenDeathProbabilities(Person.Sex sex) {
        ArrayList<Double> probabilities = suddenDeathProbabilitiesMap.get(sex);
        if (probabilities == null) {
            if (sex == Person.Sex.Female) {
                probabilities = new ArrayList<>(Arrays.asList(2.03327E-07, 2.03327E-07, 2.03327E-07, 1.19385E-06, 8.87187E-06, 1.97007E-05, 9.73804E-05));
            } else {
                probabilities = new ArrayList<>(Arrays.asList(3.79825E-07, 3.79825E-07, 3.79825E-07, 3.84118E-06, 2.00505E-05, 3.47985E-05, 0.000105441));
            }
            suddenDeathProbabilitiesMap.put(sex, probabilities);
        }
        return probabilities;
    }

    public ArrayList<Double> getHospitalProbabilities(Person.Sex sex) {
        ArrayList<Double> probabilities = hospitalProbabilitiesMap.get(sex);
        if (probabilities == null) {
            if (sex == Person.Sex.Female) {
                probabilities = new ArrayList<>(Arrays.asList(0.000116508, 5.8254E-05, 0.000452839, 0.00083018, 0.000361234, 0.000542418, 0.000785243));
            } else {
                probabilities = new ArrayList<>(Arrays.asList(0.000217643, 0.000108821, 0.000845925, 0.00267109, 0.000816392, 0.000958105, 0.00085024));
            }
            hospitalProbabilitiesMap.put(sex, probabilities);
        }
        return probabilities;
    }

    public ArrayList<Double> getHospitalDeathProbabilities(Person.Sex sex) {
        ArrayList<Double> probabilities = hospitalDeathProbabilitiesMap.get(sex);
        if (probabilities == null) {
            if (sex == Person.Sex.Female) {
                probabilities = new ArrayList<>(Arrays.asList(0.004496926, 0.002248463, 0.006745389, 0.0085665, 0.013942758, 0.020936024, 0.030308462));
            } else {
                probabilities = new ArrayList<>(Arrays.asList(0.008400475, 0.004200238, 0.012600713, 0.027562562, 0.031510735, 0.036980507, 0.032817199));
            }
            hospitalDeathProbabilitiesMap.put(sex, probabilities);
        }
        return probabilities;
    }
}
