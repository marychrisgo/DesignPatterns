package abstractFactory;

public class Ellipse implements Shape {

	@Override
	public void draw() {
		System.out.println("ellipse::draw()");

	}
}
