public abstract class AbstractDaoFactory {
    abstract StudentDao getStudentDaoImpl();
}
